# BharatShop 2.0.0 — No Vault

Standalone Paper economy and item shop. This project intentionally has **no Vault API dependency**.

## Features
- Persistent UUID-based balances in `plugins/BharatShop/balances.yml`
- Indian Rupee display (`₹`) with Indian digit grouping
- `/balance` (`/bal`, `/money`), `/stash [player]`, `/baltop`, `/pay <player> <amount>`
- `/shop`: left-click to buy one item, right-click to sell one item
- `/transactions`
- Admin: `/bs info`, `/bs reload`, `/bs balance <player>`, `/bs give|take|set <player> <amount>`

## Build
Requires Java 21 and Maven:
`mvn clean package`

Output: `target/BharatShop-2.0.0.jar`

GitHub Actions also builds the JAR on push or manual workflow dispatch and uploads it as the `BharatShop-NoVault` artifact.

## Install
1. Stop the Paper server.
2. Remove the old `BharatShop-1.0.0.jar` from `plugins` (keep a backup).
3. Upload `BharatShop-2.0.0.jar` to `plugins`.
4. Start the server. No Vault or external economy plugin is required.

**Important:** This is a new independent balance database. It does not import balances from Vault or the previous plugin. Back up old plugin data before replacing it. Test on a copy of the server first.
