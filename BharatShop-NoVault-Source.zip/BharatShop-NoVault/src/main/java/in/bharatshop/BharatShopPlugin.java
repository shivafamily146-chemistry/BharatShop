package in.bharatshop;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.NamespacedKey;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.IOException;
import java.text.NumberFormat;
import java.util.*;
import java.util.stream.Collectors;

public final class BharatShopPlugin extends JavaPlugin implements Listener {
    private YamlConfiguration data;
    private File dataFile;
    private NamespacedKey shopItemKey;
    private final Map<UUID, Double> balances = new HashMap<>();
    private final Map<UUID, String> names = new HashMap<>();
    private final List<String> transactions = new ArrayList<>();
    private final NumberFormat number = NumberFormat.getNumberInstance(new Locale("en", "IN"));

    @Override public void onEnable() {
        saveDefaultConfig();
        shopItemKey = new NamespacedKey(this, "shop_material");
        loadData();
        Bukkit.getPluginManager().registerEvents(this, this);
        for (String cmd : List.of("balance","stash","baltop","pay","shop","transactions","bharatshop")) {
            Objects.requireNonNull(getCommand(cmd), "Missing command " + cmd).setExecutor(this);
        }
        getLogger().info("BharatShop 2.0.0 enabled - standalone economy, no Vault required.");
    }

    @Override public void onDisable() { saveData(); }

    private void loadData() {
        if (!getDataFolder().exists()) getDataFolder().mkdirs();
        dataFile = new File(getDataFolder(), "balances.yml");
        data = YamlConfiguration.loadConfiguration(dataFile);
        if (data.isConfigurationSection("players")) {
            for (String id : Objects.requireNonNull(data.getConfigurationSection("players")).getKeys(false)) {
                try {
                    UUID uuid = UUID.fromString(id);
                    balances.put(uuid, data.getDouble("players." + id + ".balance"));
                    names.put(uuid, data.getString("players." + id + ".name", "Unknown"));
                } catch (IllegalArgumentException ignored) {}
            }
        }
        transactions.addAll(data.getStringList("transactions"));
    }

    private synchronized void saveData() {
        for (UUID id : new HashSet<>(balances.keySet())) {
            data.set("players." + id + ".balance", balances.getOrDefault(id, 0.0));
            data.set("players." + id + ".name", names.getOrDefault(id, "Unknown"));
        }
        data.set("transactions", transactions.stream().limit(1000).toList());
        try { data.save(dataFile); }
        catch (IOException ex) { getLogger().severe("Could not save balances.yml: " + ex.getMessage()); }
    }

    private synchronized void touch(OfflinePlayer p) {
        UUID id = p.getUniqueId();
        names.put(id, p.getName() == null ? names.getOrDefault(id, "Unknown") : p.getName());
        balances.putIfAbsent(id, getConfig().getDouble("starting-balance", 1000.0));
    }

    private synchronized double balance(OfflinePlayer p) { touch(p); return balances.get(p.getUniqueId()); }
    private String money(double value) {
        return getConfig().getString("currency-symbol", "₹") + number.format(value);
    }
    private String color(String s) { return ChatColor.translateAlternateColorCodes('&', s); }
    private void msg(CommandSender s, String m) { s.sendMessage(color("&6[BharatShop] &r" + m)); }
    private boolean validAmount(double a) {
        return Double.isFinite(a) && a > 0 && a <= getConfig().getDouble("max-transaction", 1_000_000_000.0);
    }
    private synchronized void record(String line) {
        transactions.add(0, line);
        while (transactions.size() > 1000) transactions.remove(transactions.size()-1);
        saveData();
    }
    private synchronized boolean deposit(OfflinePlayer p, double amount) {
        if (!validAmount(amount)) return false;
        touch(p); balances.put(p.getUniqueId(), balance(p) + amount); saveData(); return true;
    }
    private synchronized boolean withdraw(OfflinePlayer p, double amount) {
        if (!validAmount(amount)) return false;
        touch(p);
        double old = balance(p);
        if (old + 1e-9 < amount) return false;
        balances.put(p.getUniqueId(), old - amount); saveData(); return true;
    }

    @Override public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        String cmd = command.getName().toLowerCase(Locale.ROOT);
        switch (cmd) {
            case "balance" -> {
                if (!(sender instanceof Player p)) { msg(sender, "&cPlayers only."); return true; }
                msg(sender, "&aYour balance: &e" + money(balance(p)));
            }
            case "stash" -> {
                if (args.length == 0) {
                    if (!(sender instanceof Player p)) { msg(sender, "&cUsage: /stash <player>"); return true; }
                    msg(sender, "&aYour balance: &e" + money(balance(p)));
                } else {
                    if (!sender.hasPermission("bharatshop.balance.others")) { msg(sender, "&cNo permission."); return true; }
                    OfflinePlayer target = findPlayer(args[0]);
                    if (target == null) { msg(sender, "&cPlayer not found."); return true; }
                    msg(sender, "&e" + safeName(target) + "&a has &e" + money(balance(target)));
                }
            }
            case "baltop" -> {
                List<Map.Entry<UUID,Double>> top;
                synchronized (this) {
                    top = balances.entrySet().stream().sorted(Map.Entry.<UUID,Double>comparingByValue().reversed()).limit(10).toList();
                }
                msg(sender, "&6Top 10 richest players:");
                int rank=1;
                for (var e : top) msg(sender, "&e" + rank++ + ". &f" + names.getOrDefault(e.getKey(),"Unknown") + " &7- &a" + money(e.getValue()));
                if (top.isEmpty()) msg(sender, "&7No balances recorded yet.");
            }
            case "pay" -> {
                if (!(sender instanceof Player p)) { msg(sender, "&cPlayers only."); return true; }
                if (args.length != 2) { msg(sender, "&cUsage: /pay <player> <amount>"); return true; }
                OfflinePlayer target = findPlayer(args[0]);
                double amount;
                try { amount = Double.parseDouble(args[1]); } catch (NumberFormatException ex) { amount = -1; }
                if (target == null || !target.hasPlayedBefore() && !target.isOnline()) { msg(sender, "&cPlayer not found."); return true; }
                if (target.getUniqueId().equals(p.getUniqueId())) { msg(sender, "&cYou cannot pay yourself."); return true; }
                if (!validAmount(amount)) { msg(sender, "&cEnter a valid amount."); return true; }
                synchronized (this) {
                    if (balance(p) < amount) { msg(sender, "&cNot enough money."); return true; }
                    withdraw(p, amount); deposit(target, amount);
                }
                record("PAY|" + p.getName() + "|" + safeName(target) + "|" + amount);
                msg(sender, "&aPaid &e" + money(amount) + " &ato &e" + safeName(target) + "&a.");
                if (target.isOnline()) msg(target.getPlayer(), "&aReceived &e" + money(amount) + " &afrom &e" + p.getName() + "&a.");
            }
            case "shop" -> {
                if (!(sender instanceof Player p)) { msg(sender, "&cPlayers only."); return true; }
                openShop(p);
            }
            case "transactions" -> {
                if (!(sender instanceof Player p)) { msg(sender, "&cPlayers only."); return true; }
                msg(sender, "&6Recent transactions:");
                int count=0;
                for (String t : transactions) {
                    if (t.contains(p.getName()) && count++ < 10) msg(sender, "&7" + t);
                }
                if (count==0) msg(sender, "&7No recent transactions.");
            }
            case "bharatshop" -> {
                if (!sender.hasPermission("bharatshop.admin")) { msg(sender, "&cNo permission."); return true; }
                if (args.length == 0) { msg(sender, "&e/bs <info|reload|give|take|set|balance>"); return true; }
                switch (args[0].toLowerCase(Locale.ROOT)) {
                    case "info" -> msg(sender, "&aBharatShop 2.0.0 &7| Independent economy | Vault not required");
                    case "reload" -> { reloadConfig(); msg(sender, "&aConfiguration reloaded."); }
                    case "balance" -> {
                        if (args.length < 2) { msg(sender, "&c/bs balance <player>"); break; }
                        OfflinePlayer t=findPlayer(args[1]); if(t==null){msg(sender,"&cPlayer not found.");break;}
                        msg(sender, "&e"+safeName(t)+" &ahas &e"+money(balance(t)));
                    }
                    case "give", "take", "set" -> {
                        if (args.length < 3) { msg(sender, "&c/bs " + args[0] + " <player> <amount>"); break; }
                        OfflinePlayer t=findPlayer(args[1]); double a;
                        try { a=Double.parseDouble(args[2]); } catch(Exception ex){a=-1;}
                        if(t==null || !validAmount(a)){msg(sender,"&cInvalid player or amount.");break;}
                        touch(t);
                        synchronized(this) {
                            double old=balance(t);
                            balances.put(t.getUniqueId(), args[0].equalsIgnoreCase("give")?old+a:args[0].equalsIgnoreCase("take")?Math.max(0,old-a):a);
                            saveData();
                        }
                        record("ADMIN_"+args[0].toUpperCase(Locale.ROOT)+"|"+safeName(t)+"|"+a);
                        msg(sender, "&aUpdated " + safeName(t) + ": &e" + money(balance(t)));
                    }
                    default -> msg(sender, "&cUnknown subcommand.");
                }
            }
        }
        return true;
    }

    private OfflinePlayer findPlayer(String name) {
        Player online = Bukkit.getPlayerExact(name);
        if (online != null) return online;
        for (OfflinePlayer p : Bukkit.getOfflinePlayers()) if (p.getName()!=null && p.getName().equalsIgnoreCase(name)) return p;
        return null;
    }
    private String safeName(OfflinePlayer p) { return p.getName()==null ? "Unknown" : p.getName(); }

    private void openShop(Player p) {
        ConfigurationSection items = getConfig().getConfigurationSection("shop.items");
        if (items == null) { msg(p, "&cNo shop items configured."); return; }
        Inventory inv = Bukkit.createInventory(null, 54, color("&6BharatShop &8| &7Left: Buy / Right: Sell"));
        int slot=0;
        for (String key : items.getKeys(false)) {
            if(slot>=54) break;
            Material mat=Material.matchMaterial(key); if(mat==null) continue;
            double buy=items.getDouble(key+".buy",-1), sell=items.getDouble(key+".sell",-1);
            ItemStack stack=new ItemStack(mat);
            ItemMeta meta=stack.getItemMeta();
            meta.setDisplayName(color("&e"+key.replace('_',' ')));
            meta.setLore(List.of(color("&aBuy: &f"+money(buy)),color("&cSell: &f"+money(sell)),color("&7Left-click: buy 1"),color("&7Right-click: sell 1")));
            meta.getPersistentDataContainer().set(shopItemKey, PersistentDataType.STRING, key);
            stack.setItemMeta(meta); inv.setItem(slot++,stack);
        }
        p.openInventory(inv);
    }

    @EventHandler public void onShopClick(InventoryClickEvent e) {
        if (!(e.getWhoClicked() instanceof Player p)) return;
        if (!e.getView().getTitle().contains("BharatShop")) return;
        e.setCancelled(true);
        ItemStack clicked=e.getCurrentItem();
        if(clicked==null || !clicked.hasItemMeta()) return;
        String key=clicked.getItemMeta().getPersistentDataContainer().get(shopItemKey,PersistentDataType.STRING);
        if(key==null) return;
        ConfigurationSection section=getConfig().getConfigurationSection("shop.items."+key);
        if(section==null) return;
        double price=section.getDouble(e.isLeftClick()?"buy":"sell",-1);
        Material material=Material.matchMaterial(key);
        if(material==null || price<0) return;
        if(e.isLeftClick()) {
            if(!withdraw(p,price)){msg(p,"&cNot enough money. Your balance: &e"+money(balance(p)));return;}
            HashMap<Integer,ItemStack> leftovers=p.getInventory().addItem(new ItemStack(material));
            if(!leftovers.isEmpty()){deposit(p,price);msg(p,"&cInventory full.");return;}
            record("SHOP_BUY|"+p.getName()+"|"+key+"|"+price);
            msg(p,"&aBought 1 "+key+" for &e"+money(price));
        } else if(e.isRightClick()) {
            int slot=p.getInventory().first(material);
            if(slot<0){msg(p,"&cYou do not have that item.");return;}
            p.getInventory().setItem(slot,null); deposit(p,price);
            record("SHOP_SELL|"+p.getName()+"|"+key+"|"+price);
            msg(p,"&aSold 1 "+key+" for &e"+money(price));
        }
    }
}
